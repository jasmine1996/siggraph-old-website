This folder contains the data files for the 3D models.

petredon.ms3d - the data for the petradon
running grazing headbutting standing.ms3d - the data for the peggy
trex_WalkRoarEat.ms3d - the data for the TRex
triceratops.ms3d - not in use -- seems to be a prototype

Anyone want to add info about these?
water2.mtl
water2.obj
water.ms3d